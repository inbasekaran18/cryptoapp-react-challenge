const https = require('https')
const AWS = require('aws-sdk')
const axios = require('axios')
AWS.config.update({ region: 'ap-south-1' })
const docClient = new AWS.DynamoDB.DocumentClient()
const coinTable = 'coin_Details'
const historyTable = 'coin_history'
const coinID = 'bitcoin'
const currency = 'usd'

exports.handler = async (event) => {


  var axios = require('axios')

  var config = {
    method: 'get',
    url: 'https://api.coingecko.com/api/v3/coins/bitcoin/market_chart/range?vs_currency=usd&from=1660811665&to=1663490201',
    headers: {}
  }

  axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data))
    })
    .catch(function (error) {
      console.log(error)
    })


    
  // initialising the coin details
  var defaultOptions = {
    method: 'GET',
    hostname: 'api.coingecko.com',
    port: null,
    headers: {
      'cache-control': 'no-cache',
      'Content-Type': 'application/json'
    }
  }
  let response
  try {
    // Get coin details
    const getCoinInfo = await getStatus(
      defaultOptions,
      `/api/v3/coins/${coinID}`,
      {}
    )
    // Post coin details
    const coinInfoRes = await postCoin({
      body: JSON.stringify(getCoinInfo)
    })


    // Get coin history
    let fromDate = unixTimestamp(
      new Date(new Date().setFullYear(new Date().getFullYear() - 5))
    )

    // let fromDate = unixTimestamp(new Date(Date.now() - 10000 * 60))
    const getLastItem = await getChartDataLast(coinID)

    const lastItem = getLastItem.body
    const lastItemData = JSON.parse(lastItem).Items
    if (
      lastItemData[0]?.unixTimestamp != undefined &&
      lastItemData[0]?.unixTimestamp != null &&
      lastItemData[0]?.unixTimestamp != ''
    ) {
      fromDate = lastItemData[0].unixTimestamp
    }

    console.log(
      `/api/v3/coins/${coinID}/market_chart/range?vs_currency=${currency}&from=${fromDate}&to=${unixTimestamp(
        Date.now()
      )}`
    )

    const getHistory = await getStatus(
      defaultOptions,
      `/api/v3/coins/${coinID}/market_chart/range?vs_currency=${currency}&from=${fromDate}&to=${unixTimestamp(
        Date.now()
      )}`,
      {}
    )

    console.log(`Total records from  api : ${getHistory.prices.length} `)
    //Post coin history
    const coinHistoryRes = await postChartData({
      body: JSON.stringify(getHistory.prices)
    })
    // Response for coin details and history
    return (response = {
      statusCode: 200,
      type: 'Main Response',
      body: `${JSON.stringify(coinInfoRes)} ${JSON.stringify(coinHistoryRes)} `
    })
  } catch (err) {
    return (response = {
      statusCode: 500,
      type: 'Main Response',
      body: JSON.stringify(err)
    })
  }
}

// Method for posting coin details
const postCoin = async (rawData) => {
  let response
  const body = JSON.parse(rawData.body)
  const { id, symbol, name, market_data } = body
  const params = {
    TableName: coinTable,
    Key: {
      coinId: id
    },
    ReturnValues: 'ALL_OLD',
    Item: {
      coinId: id,
      symbol,
      name,
      market_cap_rank: market_data.market_cap_rank,
      current_price: market_data.current_price.usd,
      market_cap: market_data.market_cap.usd,
      price_change_percentage_1h_in_currency:
        market_data.price_change_percentage_1h_in_currency.usd,
      price_change_percentage_7d_in_currency:
        market_data.price_change_percentage_7d_in_currency.usd,
      market_cap_change_24h_in_currency:
        market_data.market_cap_change_24h_in_currency.usd,
      market_cap_change_percentage_24h_in_currency:
        market_data.market_cap_change_percentage_24h_in_currency.usd,
      price_change_24h: market_data.price_change_24h.usd,
      price_change_percentage_24h: market_data.price_change_percentage_24h,
      price_change_percentage_7d: market_data.price_change_percentage_7d,
      price_change_percentage_14d: market_data.price_change_percentage_14d,
      price_change_percentage_30d: market_data.price_change_percentage_30d,
      price_change_percentage_200d: market_data.price_change_percentage_200d,
      price_change_percentage_1y: market_data.price_change_percentage_1y,
      market_cap_change_24h: market_data.market_cap_change_24h,
      market_cap_change_percentage_24h:
        market_data.market_cap_change_percentage_24h,
      price_change_24h_in_currency:
        market_data.price_change_24h_in_currency.usd,
      total_volume: market_data.total_volume.usd
    }
  }
  try {
    const data = await docClient.put(params).promise()
    response = {
      statusCode: 200,
      type: 'coin details Ingestion',
      body: JSON.stringify(data)
    }
  } catch (err) {
    response = {
      statusCode: 500,
      type: 'coin details Ingestion',
      body: JSON.stringify(err)
    }
  }
  return response
}

// Method for getting latest coin history
const getChartDataLast = async (id) => {
  let response
  let params = {
    TableName: historyTable,
    ScanIndexForward: false,
    Limit: 1
  }

  try {
    const data = await docClient.scan(params).promise()
    response = {
      statusCode: 200,
      type: 'coin details get',
      body: JSON.stringify(data)
    }
  } catch (err) {
    response = {
      statusCode: 500,
      type: 'coin details get',
      body: JSON.stringify(err)
    }
  }
  return response
}

// Method for posting coin details
const postChartData = async (streamData) => {
  const streamD = JSON.parse(streamData.body)
  let response = {
    statusCode: 200,
    type: 'coin history Ingestion',
    body: { message: 'response without running DB ' }
  }

  if (streamD.length === 0) {
    response = {
      statusCode: 200,
      type: 'coin history Ingestion',
      body: {
        message: `No records available to insert count : ${streamD.length} `
      }
    }
  }

  await streamD.forEach(async (stream) => {
    const uniqueId = `${AWS.util.uuid.v4()}-${Math.random()}`
    console.log(stream);
    const params = {
      TableName: historyTable,
      Item: {
        coinHistoryId: uniqueId.toString(),
        price: stream[1],
        unixTimestamp: stream[0],
        coin: coinID.toString()
      }
    }

    console.log(params)

    try {
      await docClient.put(params, function async(err, data) {
        if (err) {
          console.error(err)
        } else {
          console.error('data inserted')
        }
      })
    } catch (err) {
      console.log(err)
      response = {
        statusCode: 200,
        type: 'coin history Ingestion',
        body: JSON.stringify(err)
      }
    }
    return false
  })
  return response
}

// Common Method for getting data from api
const getStatus = (defaultOptions, path, payload) =>
  new Promise((resolve, reject) => {
    const options = { ...defaultOptions, path, method: 'GET' }
    const req = https.request(options, (res) => {
      let buffer = ''
      res.on('data', (chunk) => (buffer += chunk))
      res.on('end', () => resolve(JSON.parse(buffer)))
    })
    req.on('error', (e) => reject(e.message))
    req.write(JSON.stringify(payload))
    req.end()
  })
// Common Method for unix timestamp
const unixTimestamp = (date) => {
  return Math.floor(date / 1000)
}
